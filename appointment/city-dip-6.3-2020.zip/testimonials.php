<?php
include_once('header_main.php');
?>	<section class="inner_page_banner_sec parallax_effect-" style="background-image:url('images/inner_banner_about.jpg');">
		<div class="container">
			<div class="row">
				<div class="col-sm-12" style="position:relative;">
					<div class="inner_banner_content">
						<h1>Testimonials</h1>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- testimonial_page_sec -->
	<section class="testimonial_page_sec bg_color_light_gray">
  <div class="container">
	<div class="row">
      <div class="col-sm-12">
        <div class="heading_box_comman">
          <h2 class="wow fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">Our <span class="txt_color_blue">Testimonial</span></h2>
          <p class="wow fadeInDown animated" style="visibility: visible; animation-name: fadeInDown;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown</p>
		  <br>
        </div>
      </div>
    </div>
	<div class="comman_top">
    <div class="row">
        <div class="col-lg-6 col-md-6 col-sm-12 course_box_main">
          <div class="course_box_inner">
            <div class="courses_box text-center wow fadeInDown animated">
              <div class="course_icon"> <img src="images/testimonial1.jpg" alt="" /> </div>
              
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled. </p>
			  <h3>Aananda, UI Developer</h3>
              </div>
          </div>
        </div>
		<div class="col-lg-6 col-md-6 col-sm-12 course_box_main">
          <div class="course_box_inner">
            <div class="courses_box text-center wow fadeInDown animated">
              <div class="course_icon"> <img src="images/testimonial2.jpg" alt="" /> </div>
              
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
			  <h3>Admin</h3>
              </div>
          </div>
        </div>
        <div class="col-lg-6 col-md-6 col-sm-12 course_box_main">
          <div class="course_box_inner">
            <div class="courses_box text-center wow fadeInDown animated" style="visibility: visible; animation-name: fadeInDown;">
              <div class="course_icon"><img src="images/testimonial_blank.jpg" alt="" /></div>
              
              <p>Build your future We provide personalised counselling for visa process ,financial documentation,shortlisting universities,course selection; assistance..</p>
			  <h3>Domestic Education</h3>
               </div>
          </div>
        </div>
        <div class="col-lg-6 col-md-6 col-sm-12 course_box_main">
          <div class="course_box_inner">
            <div class="courses_box text-center wow fadeInDown animated">
              <div class="course_icon"> <img src="images/testimonial3.jpg" alt="" /> </div>
              
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
			  <h3>Aananda, UI Developer</h3>
              </div>
          </div>
        </div>
		<div class="col-lg-6 col-md-6 col-sm-12 course_box_main">
          <div class="course_box_inner">
            <div class="courses_box text-center wow fadeInDown animated">
              <div class="course_icon"> <img src="images/testimonial1.jpg" alt="" /> </div>
              
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled. </p>
			  <h3>Aananda, UI Developer</h3>
              </div>
          </div>
        </div>
		<div class="col-lg-6 col-md-6 col-sm-12 course_box_main">
          <div class="course_box_inner">
            <div class="courses_box text-center wow fadeInDown animated">
              <div class="course_icon"> <img src="images/testimonial2.jpg" alt="" /> </div>
              
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
			  <h3>Admin</h3>
              </div>
          </div>
        </div>
        <div class="col-lg-6 col-md-6 col-sm-12 course_box_main">
          <div class="course_box_inner">
            <div class="courses_box text-center wow fadeInDown animated" style="visibility: visible; animation-name: fadeInDown;">
              <div class="course_icon"><img src="images/testimonial_blank.jpg" alt="" /></div>
              
              <p>Build your future We provide personalised counselling for visa process ,financial documentation,shortlisting universities,course selection; assistance..</p>
			  <h3>Domestic Education</h3>
               </div>
          </div>
        </div>
        <div class="col-lg-6 col-md-6 col-sm-12 course_box_main">
          <div class="course_box_inner">
            <div class="courses_box text-center wow fadeInDown animated">
              <div class="course_icon"> <img src="images/testimonial3.jpg" alt="" /> </div>
              
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
			  <h3>Aananda, UI Developer</h3>
              </div>
          </div>
        </div>
      </div>
	  </div>

  </div>
</section>
<?php
include_once('footer _main.php');
?>